package CodigosFonteCampoMinado;

import InterfaceCampoMinado.InterfaceTabuleiro;

public class Main {

	public static void main(String[] args) {
		InterfaceTabuleiro i = new InterfaceTabuleiro();

	}
	
	public static void reconfigurar() {
		InterfaceTabuleiro i = new InterfaceTabuleiro();
	}
}
